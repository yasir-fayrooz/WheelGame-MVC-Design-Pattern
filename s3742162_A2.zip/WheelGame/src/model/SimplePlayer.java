package model;

import model.enumeration.BetType;
import model.interfaces.Player;

public class SimplePlayer implements Player{
	
	private String ID;
	private String name;
	private int points;
	private BetType betType = null;
	private int bet = 0;

	public SimplePlayer(String ID, String name, int points) {
		this.ID = ID;
		this.name = name;
		this.points = points;
	}

	@Override
	public String getPlayerName() {
		return name;
	}

	@Override
	public void setPlayerName(String playerName) {
		this.name = playerName;
	}

	@Override
	public int getPoints() {
		return points;
	}

	@Override
	public void setPoints(int points) {
		this.points = points;
	}

	@Override
	public String getPlayerId() {
		return ID;
	}

	@Override
	public boolean setBet(int bet) {
		if(this.bet == 0)
		{
			this.bet = bet;
			return true;
		}
		return false;
		
	}

	@Override
	public int getBet() {
		return bet;
	}

	@Override
	public void setBetType(BetType betType) {
		this.betType = betType;
		
	}

	@Override
	public BetType getBetType() {
		return betType;
	}

	@Override
	public void resetBet() {
		this.betType = null;
		this.bet = 0;
	}
	
	@Override
	   public String toString() {
		return "\nPlayer: id=" + ID + 
			   ", name=" + name + 
			   ", bet=" + bet + 
			   ", betType=" + betType +
			   ", points=" + points;
	}

}
