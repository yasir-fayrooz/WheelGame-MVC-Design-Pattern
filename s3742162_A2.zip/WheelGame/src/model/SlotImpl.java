package model;

import model.enumeration.Color;
import model.interfaces.Slot;

public class SlotImpl implements Slot{
	
	private int position;
	private int number;
	private Color color;

	public SlotImpl(int position, int number, Color color)
	{
		this.position = position;
		this.number = number;
		this.color = color;
	}
	
	@Override
	public int getPosition() {
		return position;
	}

	@Override
	public int getNumber() {
		return number;
	}

	@Override
	public Color getColor() {
		return color;
	}

	@Override
	public boolean equals(Slot slot) {
		// TODO Auto-generated method stub
		return false;
	}
	
   @Override
   public String toString(){
	   return "Position: " + position + ", Color: " + color + ", Number: " + number;
   }

}
