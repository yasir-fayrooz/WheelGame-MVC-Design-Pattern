package model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Random;

import model.enumeration.BetType;
import model.enumeration.Color;
import model.interfaces.GameEngine;
import model.interfaces.Player;
import model.interfaces.Slot;
import view.interfaces.GameEngineCallback;

public class GameEngineImpl implements GameEngine{
	
	private ArrayList<Player> players = new ArrayList<Player>();
	
	private ArrayList<GameEngineCallback> gec = new ArrayList<GameEngineCallback>();
	
	private ArrayList<Slot> slots = new ArrayList<>(Arrays.asList(
			new SlotImpl(0, 0, Color.GREEN00),
			new SlotImpl(1, 27, Color.RED),
			new SlotImpl(2, 10, Color.BLACK),
			new SlotImpl(3, 25, Color.RED),
			new SlotImpl(4, 29, Color.BLACK),
			new SlotImpl(5, 12, Color.RED),
			new SlotImpl(6, 8, Color.BLACK),
			new SlotImpl(7, 19, Color.RED),
			new SlotImpl(8, 31, Color.BLACK),
			new SlotImpl(9, 18, Color.RED),
			new SlotImpl(10, 6, Color.BLACK),
			new SlotImpl(11, 21, Color.RED),
			new SlotImpl(12, 33, Color.BLACK),
			new SlotImpl(13, 16, Color.RED),
			new SlotImpl(14, 4, Color.BLACK),
			new SlotImpl(15, 23, Color.RED),
			new SlotImpl(16, 35, Color.BLACK),
			new SlotImpl(17, 14, Color.RED),
			new SlotImpl(18, 2, Color.BLACK),
			new SlotImpl(19, 0, Color.GREEN0),
			new SlotImpl(20, 28, Color.BLACK),
			new SlotImpl(21, 9, Color.RED),
			new SlotImpl(22, 26, Color.BLACK),
			new SlotImpl(23, 30, Color.RED),
			new SlotImpl(24, 11, Color.BLACK),
			new SlotImpl(25, 7, Color.RED),
			new SlotImpl(26, 20, Color.BLACK),
			new SlotImpl(27, 32, Color.RED),
			new SlotImpl(28, 17, Color.BLACK),
			new SlotImpl(29, 5, Color.RED),
			new SlotImpl(30, 22, Color.BLACK),
			new SlotImpl(31, 34, Color.RED),
			new SlotImpl(32, 15, Color.BLACK),
			new SlotImpl(33, 3, Color.RED),
			new SlotImpl(34, 24, Color.BLACK),
			new SlotImpl(35, 36, Color.RED),
			new SlotImpl(36, 13, Color.BLACK),
			new SlotImpl(37, 1, Color.RED)
			));
	
	@Override
	public void spin(int initialDelay, int finalDelay, int delayIncrement) {
		Random number = new Random();
		int startingNumber = number.nextInt(37);
		
		for(int i = initialDelay; i <= finalDelay; i = i + delayIncrement)
		{
			for(GameEngineCallback g: gec)
			{
				g.nextSlot(slots.get(startingNumber), this);
			}
			startingNumber = ((startingNumber + 1) % 38);
			try { Thread.sleep(i); } catch (InterruptedException e) {}
		}
		for(GameEngineCallback g: gec)
		{
			g.result(slots.get(startingNumber), this);
		}
	}

	@Override
	public void calculateResult(Slot winningSlot) {
		for(Player p: players)
		{
			if(p.getBetType() != null)
			{
				p.getBetType().applyWinLoss(p, winningSlot);
			}
		}
	}

	@Override
	public void addPlayer(Player player) {
		players.add(player);
	}

	@Override
	public Player getPlayer(String id) {
		
		for(Player player : players)
		{
			if(player.getPlayerId().equals(id))
			{
				return player;
			}
		}
		
		return null;
	}

	@Override
	public boolean removePlayer(Player player) {
		for(int i = 0; i < players.size(); i++)
		{
			if(players.get(i).equals(player))
			{
				players.remove(i);
				return true;
			}
		}
		return false;
	}

	@Override
	public void addGameEngineCallback(GameEngineCallback gameEngineCallback) {
		gec.add(gameEngineCallback);
	}

	@Override
	public boolean removeGameEngineCallback(GameEngineCallback gameEngineCallback) {
		
		for(GameEngineCallback g: gec)
		{
			if(g.equals(gameEngineCallback))
			{
				gec.remove(gameEngineCallback);
				return true;
			}
		}
		return false;
	}

	@Override
	public Collection<Player> getAllPlayers() {
		return players;
	}

	@Override
	public boolean placeBet(Player player, int bet, BetType betType) {
		if(player.getPoints() - bet >= 0)
		{
			player.setBet(bet);
			player.setBetType(betType);
			return true;
		}
		return false;
	}

	@Override
	public Collection<Slot> getWheelSlots() {
		return slots;
	}

}
