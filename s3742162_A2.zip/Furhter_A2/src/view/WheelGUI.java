package view;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;

import model.interfaces.GameEngine;
import model.interfaces.Slot;

public class WheelGUI extends JPanel {
	
	BufferedImage wheel;
	JFrame frame;
	
	int currentSlotPos = 0;
	
	public WheelGUI(JFrame frame)
	{
		this.frame = frame;
		
		try {
			wheel = ImageIO.read(new File("Wheel.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        int dimension;
        if(this.getWidth() > this.getHeight())
        {
        	dimension = this.getHeight();
        }
        else
        {
        	dimension = this.getWidth();
        }
        g.drawImage(wheel, 0, 0, dimension, dimension, this);
        
        g.setColor(Color.blue);
        if(currentSlotPos != 0)
        {
        	int r = (dimension / 2) - 15;
        	double points = 360 / 38.3;
        	double theta = Math.toRadians((points * currentSlotPos) - (9 * points) - 5);
        	int XPos = (int) (r * Math.cos(theta));
        	int YPos = (int) (r * Math.sin(theta));
        	
        	g.fillOval(XPos + r, YPos + r, 20, 20);
        }
        else
        {
        	int r = (dimension / 2) - 15;
        	double points = 360 / 38.3;
        	double theta = Math.toRadians((points * currentSlotPos) - (9 * points) - 5);
        	int XPos = (int) (r * Math.cos(theta));
        	int YPos = (int) (r * Math.sin(theta));
        	g.fillOval(XPos + r, YPos + r, 20, 20);
        }
    }
    
    
    public void updateGUI(Slot slot, GameEngine engine)
    {
    	currentSlotPos = slot.getPosition();
    	repaint();
    }
}
