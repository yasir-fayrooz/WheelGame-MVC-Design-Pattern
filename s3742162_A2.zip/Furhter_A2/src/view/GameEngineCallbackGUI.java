package view;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Panel;
import java.awt.event.KeyEvent;
import java.io.PrintStream;
import java.util.Collection;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JToolBar;
import javax.swing.SwingUtilities;

import client.SimpleTestClient;
import model.interfaces.GameEngine;
import model.interfaces.Player;
import model.interfaces.Slot;
import view.interfaces.GameEngineCallback;

public class GameEngineCallbackGUI implements GameEngineCallback{
   
	private static final Logger logger = Logger.getLogger(SimpleTestClient.class.getName());
	
	JFrame frame;
	SummaryPanel summaryPanel;
	WheelGUI wheelGUI;
	JMenuBar menuBar;
	JToolBar toolBar;
	JPanel console;
	JTextArea consoleText = new JTextArea(7, 70);
	
	public GameEngineCallbackGUI(GameEngine gameEngine)
	{
		frame = new JFrame("Further Programming A2 - s3742162");
		frame.setLayout(new BorderLayout());
		frame.getContentPane();
		frame.setBackground(Color.LIGHT_GRAY);
		
		frame.setSize(880,850);
		frame.setLocationRelativeTo(null);
		frame.setResizable(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		summaryPanel = new SummaryPanel(gameEngine, frame, this);
		summaryPanel.setPreferredSize(new Dimension(200,720));
		
		wheelGUI = new WheelGUI(frame);
		
		addStatusBar();
		
		addMenuItems();
		
		addComponents(gameEngine);
		
		frame.setVisible(true);
	}
	
	private void addMenuItems()
	{
		menuBar = new JMenuBar();
		JMenu file = new JMenu("File");
		JMenuItem test123 = new JMenuItem("test123", KeyEvent.VK_S);
		file.add(test123);
		menuBar.add(file);
		
		toolBar = new JToolBar();
		JComboBox<String> cb = new JComboBox<String>(new String[] { "item 1", "item 2", "item 3" }); 
		cb.setMaximumSize(new Dimension(50,20));
		JButton toolButton = new JButton("Toolbar test");
		toolButton.setPreferredSize(new Dimension(30,10));
		toolBar.add(cb);
		toolBar.add(toolButton);
		
		menuBar.add(toolBar);
	}
	
	private void addStatusBar()
	{
		//South panel which includes the console
		console = new JPanel();
		console.setLayout(new BoxLayout(console, BoxLayout.PAGE_AXIS));
		Console cons = new Console(consoleText, 10);
		System.setOut(new PrintStream(cons));
		console.add(new JScrollPane(consoleText));
		frame.add(console, BorderLayout.SOUTH);
	}
	
	private void addComponents(GameEngine gameEngine)
	{
		frame.add(wheelGUI, BorderLayout.CENTER);
		frame.add(summaryPanel, BorderLayout.WEST);
		frame.add(menuBar, BorderLayout.NORTH);
	}

	@Override
	public void nextSlot(Slot slot, GameEngine engine) {
		 SwingUtilities.invokeLater(new Runnable()
		 {
		 @Override
		 public void run()
		 {
			wheelGUI.updateGUI(slot, engine);
			System.out.println(slot.toString());
		 }
		 });
	}

	@Override
	public void result(Slot winningSlot, GameEngine engine) {
		System.out.println("\nRESULT:\n");
		System.out.println(winningSlot.toString());

		 SwingUtilities.invokeLater(new Runnable()
		 {
		 @Override
		 public void run()
		 {
			wheelGUI.updateGUI(winningSlot, engine);
			summaryPanel.add(summaryPanel.addButtonPanel(), BorderLayout.SOUTH);
			summaryPanel.updateGUI(engine, frame);
			summaryPanel.revalidate();
		 }
		 });
	}
	
    public void spin(GameEngine gameEngine) {
    	summaryPanel.removeSpin();
	       new Thread()
	       {
		       @Override
		       public void run()
		       {
			       // check the wheel creation is correct by inspecting logs
			       logWheel(gameEngine.getWheelSlots());

			       logger.log(Level.INFO, "SPINNING ...");
			       // NOTE: result logging is done via GameEngineCallback.result() 
			       // after it calls GameEngine.calculateResult())
			       // OutputTrace.txt was generated with these parameter values
			       gameEngine.spin(1, 500, 25);

			       // TODO reset bets for next round if you were playing again
		       }
	       }.start();
    }
    
    // private helper method to log wheel slots
    private static void logWheel(Collection<Slot> wheel)
    {
       logger.log(Level.INFO, "LOGGING WHEEL DATA CREATED BY GameEngineImpl");
       for (Slot slot : wheel)
          logger.log(Level.INFO, slot.toString());
       logger.log(Level.INFO, "END WHEEL LOG\n");
    }

}
