package view;

import java.awt.Color;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Panel;
import java.awt.TextField;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import controller.AddPlayerListener;
import model.interfaces.GameEngine;

public class AddPlayerGUI {
	JDialog dialog;
	
	JButton addPlayerButton;
	
	TextField nameTextField = new TextField(10);
	TextField pointsField = new TextField(5);
	
	public AddPlayerGUI(GameEngine gameEngine, JFrame frame, SummaryPanel summaryPanel)
	{
		
		dialog = new JDialog(frame, "", Dialog.ModalityType.DOCUMENT_MODAL);
		
		addPlayerButton = new JButton("Add");
		addPlayerButton.addActionListener(new AddPlayerListener(gameEngine, dialog, frame, nameTextField, pointsField, summaryPanel));
		
		dialog.setBackground(Color.LIGHT_GRAY);
		
		dialog.setSize(200,200);
		dialog.setLocationRelativeTo(null);
		dialog.setResizable(false);
		dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		
		dialog.add(playerForms());
		
		dialog.setVisible(true);
	}
	
	private JPanel playerForms()
	{
		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.PAGE_AXIS));
		
		
		JPanel topPanel = new JPanel();
		topPanel.setLayout(new FlowLayout());
		topPanel.add(new JLabel("Add Player: "));
		panel.add(topPanel);
		
		JPanel namePanel = new JPanel();
		namePanel.setLayout(new FlowLayout());
		namePanel.add(new JLabel("Name: "));
		namePanel.add(nameTextField);
		panel.add(namePanel);
		
		JPanel pointsPanel = new JPanel();
		pointsPanel.setLayout(new FlowLayout());
		pointsPanel.add(new JLabel("Points: "));
		pointsPanel.add(pointsField);
		panel.add(pointsPanel);
		
		JPanel addPlayerBtn = new JPanel();
		addPlayerBtn.setLayout(new FlowLayout());
		addPlayerBtn.add(addPlayerButton);
		panel.add(addPlayerBtn);
		
		return panel;
	}

}
