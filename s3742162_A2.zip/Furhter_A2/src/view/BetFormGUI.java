package view;

import java.awt.Color;
import java.awt.Dialog;
import java.awt.FlowLayout;
import java.awt.TextField;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import controller.SetBetListener;
import model.interfaces.GameEngine;
import model.interfaces.Player;

public class BetFormGUI {
	
	JDialog dialog;
	JButton setBetButton;
	TextField betField = new TextField(5);
	JComboBox<String> betType = new JComboBox<String>();
	
	public BetFormGUI(Player player, JFrame frame, SummaryPanel summaryPanel, GameEngine gameEngine)
	{
		dialog = new JDialog(frame, "", Dialog.ModalityType.DOCUMENT_MODAL);
		
		setBetButton = new JButton("Set bet");
		setBetButton.addActionListener(new SetBetListener(player, frame, summaryPanel, betField, dialog, gameEngine, betType));
		
		dialog.setBackground(Color.LIGHT_GRAY);
		
		dialog.setSize(200,200);
		dialog.setLocationRelativeTo(null);
		dialog.setResizable(false);
		dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		
		dialog.add(betForms(player));
		
		dialog.setVisible(true);
	}
	
	
	private JPanel betForms(Player player)
	{
		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.PAGE_AXIS));
		
		
		JPanel topPanel = new JPanel();
		topPanel.setLayout(new FlowLayout());
		topPanel.add(new JLabel("Set Bet " + player.getPlayerName() + ":"));
		panel.add(topPanel);
		
		JPanel betPanel = new JPanel();
		betPanel.setLayout(new FlowLayout());
		betPanel.add(new JLabel("Bet: "));
		betPanel.add(betField);
		panel.add(betPanel);
		
		JPanel betTypePanel = new JPanel();
		betTypePanel.setLayout(new FlowLayout());
		betTypePanel.add(new JLabel("Bet Type: "));
		// add items to the combo box
		betType.addItem("Black");
		betType.addItem("Red");
		betType.addItem("Green");
		betTypePanel.add(betType);
		panel.add(betTypePanel);
		
		JPanel betBtn = new JPanel();
		betBtn.setLayout(new FlowLayout());
		betBtn.add(setBetButton);
		panel.add(betBtn);
		
		return panel;
	}

}
