package view;

import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class ErrorDialog {
	
	JDialog dialog;
	
	public ErrorDialog(String error, JFrame frame)
	{
		dialog = new JDialog(frame, "", Dialog.ModalityType.DOCUMENT_MODAL);
		
		dialog.add(errorPanel(error));
		
		dialog.setSize(new Dimension(error.length() * 10, 100));
		
		dialog.setLocationRelativeTo(null);
		dialog.setResizable(false);
		dialog.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
		dialog.setVisible(true);
	}
	
	private Panel errorPanel(String error)
	{
		Panel centerText = new Panel();
		centerText.setLayout(new FlowLayout());		
		centerText.add(new JLabel(error));

		Panel centerButton = new Panel();
		centerButton.setLayout(new FlowLayout());
		JButton okButton = new JButton("Ok");
		okButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				dialog.dispose();
			}
		});
		centerButton.add(okButton);
		
		Panel errorPanel = new Panel();
		errorPanel.setLayout(new BoxLayout(errorPanel, BoxLayout.PAGE_AXIS));
		errorPanel.add(centerText);
		errorPanel.add(centerButton);
		
		return errorPanel;
	}

}
