package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import controller.AddPlayerButtonListener;
import controller.SpinButtonListener;
import controller.BetButtonListener;
import controller.RemovePlayerListener;
import model.interfaces.GameEngine;
import model.interfaces.Player;

public class SummaryPanel extends JPanel {
	
	JLabel heading = new JLabel("Player info:");
	JButton addPlayerButton = new JButton("Add players");
	JButton spinButton = new JButton("Spin!");
	
	JPanel headingPanel = headingPanel();
	JPanel playerPanel;
	JPanel ButtonPanel;
	
	public SummaryPanel(GameEngine gameEngine, JFrame frame, GameEngineCallbackGUI gecGUI)
	{
		playerPanel = playerPanel(gameEngine, frame);
		playerPanel.setLayout(new GridLayout(5,0));
		ButtonPanel = addButtonPanel();
		setLayout(new BorderLayout());
		add(headingPanel, BorderLayout.NORTH);
		add(playerPanel, BorderLayout.CENTER);
		add(ButtonPanel, BorderLayout.SOUTH);
		setBorder(BorderFactory.createLineBorder(Color.black));
		
		addActionListeners(gameEngine, frame, gecGUI);
	}
	
	
	private void addActionListeners(GameEngine gameEngine, JFrame frame, GameEngineCallbackGUI gecGUI)
	{
		spinButton.addActionListener(new SpinButtonListener(gameEngine, frame, gecGUI));
		addPlayerButton.addActionListener(new AddPlayerButtonListener(gameEngine, frame, this));
	}
	
	
	private JPanel playerPanel(GameEngine gameEngine, JFrame frame)
	{
		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		panel.setPreferredSize(new Dimension(100,100));
		for(Player player: gameEngine.getAllPlayers())
		{
			JPanel playerInfo = playerInfoPanel(player, frame, gameEngine);
			playerPanel.add(playerInfo);
		}
		
		return panel;
	}
	
	private JPanel playerInfoPanel(Player player, JFrame frame, GameEngine gameEngine)
	{
		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.PAGE_AXIS));
		//panel.setPreferredSize(new Dimension(140,200));
		
		
		JPanel idPanel = new JPanel();
		idPanel.setLayout(new FlowLayout());
		JButton removeBtn = new JButton("remove");
		removeBtn.addActionListener(new RemovePlayerListener(gameEngine, player, this, frame));
		idPanel.add(removeBtn);
		idPanel.add(new JLabel("ID: "));
		idPanel.add(new JLabel(player.getPlayerId()));
		panel.add(idPanel);
		
		JPanel namePanel = new JPanel();
		namePanel.setLayout(new FlowLayout());
		namePanel.add(new JLabel("Name: "));
		namePanel.add(new JLabel(player.getPlayerName()));
		panel.add(namePanel);
		
		JPanel pointsPanel = new JPanel();
		pointsPanel.setLayout(new FlowLayout());
		pointsPanel.add(new JLabel("Points: "));
		pointsPanel.add(new JLabel("" + player.getPoints()));
		panel.add(pointsPanel);
		
		JPanel betPanel = new JPanel();
		betPanel.setLayout(new FlowLayout());
		betPanel.add(new JLabel("Bet: "));
		betPanel.add(new JLabel("" + player.getBet()));
		if(player.getBetType() == null)
		{
			JButton betButton = new JButton("Bet");
			betButton.addActionListener(new BetButtonListener(player, frame, this, gameEngine));
			betPanel.add(betButton);
		}
		else
		{
			betPanel.add(new JLabel(" Bet Type: "));
			betPanel.add(new JLabel("" + player.getBetType().toString()));
		}
		panel.add(betPanel);
		
		return panel;
	}
	
	public JPanel addButtonPanel()
	{
		JPanel panel = new JPanel();
		
		panel.add(addPlayerButton);
		
		panel.add(spinButton);
		
		return panel;
	}
	
	private JPanel headingPanel()
	{
		JPanel panel = new JPanel();
		
		panel.setLayout(new FlowLayout());
		panel.add(heading);
		
		return panel;
	}
	
	public void updateGUI(GameEngine gameEngine, JFrame frame)
	{
		playerPanel.removeAll();
		playerPanel.add(playerPanel(gameEngine, frame));
		playerPanel.revalidate();
		
		revalidate();
	}
	
	public void removeSpin()
	{
		this.remove(2);
		revalidate();
	}
}
