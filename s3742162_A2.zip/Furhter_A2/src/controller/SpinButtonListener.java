package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;

import model.interfaces.GameEngine;
import model.interfaces.Player;
import view.ErrorDialog;
import view.GameEngineCallbackGUI;

public class SpinButtonListener implements ActionListener {
	
	GameEngine gameEngine;
	JFrame frame;
	GameEngineCallbackGUI gecGUI;
	
	public SpinButtonListener(GameEngine gameEngine, JFrame frame, GameEngineCallbackGUI gecGUI)
	{
		this.gameEngine = gameEngine;
		this.frame = frame;
		this.gecGUI = gecGUI;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		
		boolean betSet = false;
		
		for(Player player: gameEngine.getAllPlayers())
		{
			if(player.getBet() != 0)
			{
				betSet = true;
			}
		}
		
		if(betSet == true)
		{
			gecGUI.spin(gameEngine);
		}
		else
		{
			new ErrorDialog("No bets have been placed yet!", frame);
		}
		
	}

}
