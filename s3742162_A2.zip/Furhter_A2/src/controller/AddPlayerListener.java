package controller;

import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JDialog;
import javax.swing.JFrame;

import model.SimplePlayer;
import model.interfaces.GameEngine;
import view.ErrorDialog;
import view.SummaryPanel;

public class AddPlayerListener implements ActionListener{

	GameEngine gameEngine;
	JDialog dialog;
	JFrame frame;
	TextField nameTextField;
	TextField pointsField;
	SummaryPanel summaryPanel;
	
	public AddPlayerListener(GameEngine gameEngine, JDialog dialog, JFrame frame, TextField nameTextField, TextField pointsField, SummaryPanel summaryPanel)
	{
		this.gameEngine = gameEngine;
		this.dialog = dialog;
		this.frame = frame;
		this.nameTextField = nameTextField;
		this.pointsField = pointsField;
		this.summaryPanel = summaryPanel;
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		if(playerValidation(nameTextField.getText(), pointsField.getText()) == false)
		{
			new ErrorDialog("Input validation error!", frame);
		}
		else
		{
			String id = "" + (gameEngine.getAllPlayers().size() + 1);
			gameEngine.addPlayer(new SimplePlayer(id, nameTextField.getText(), Integer.parseInt(pointsField.getText())));
			summaryPanel.updateGUI(gameEngine, frame);
			dialog.dispose();
		}
	}
	
	private boolean playerValidation(String nameTextField, String pointsField)
	{
		if(nameTextField.length() < 1)
		{
			return false;
		}
		
		try
		{
			int points = Integer.parseInt(pointsField);
			if(points > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		catch(Exception e)
		{
			return false;
		}
	}

}
