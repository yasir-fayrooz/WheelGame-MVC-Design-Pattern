package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;

import model.interfaces.GameEngine;
import model.interfaces.Player;
import view.SummaryPanel;

public class RemovePlayerListener implements ActionListener{

	GameEngine gameEngine;
	Player player;
	SummaryPanel summaryPanel;
	JFrame frame;
	
	public RemovePlayerListener(GameEngine gameEngine, Player player, SummaryPanel summaryPanel, JFrame frame)
	{
		this.gameEngine = gameEngine;
		this.player = player;
		this.summaryPanel = summaryPanel;
		this.frame = frame;
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		
		gameEngine.removePlayer(player);
		summaryPanel.updateGUI(gameEngine, frame);
	}

}
