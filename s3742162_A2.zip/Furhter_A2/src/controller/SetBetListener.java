package controller;

import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;

import model.enumeration.BetType;
import model.interfaces.GameEngine;
import model.interfaces.Player;
import view.ErrorDialog;
import view.SummaryPanel;

public class SetBetListener implements ActionListener{

	Player player;
	JFrame frame;
	SummaryPanel summaryPanel;
	TextField betField;
	JDialog dialog;
	GameEngine gameEngine;
	JComboBox<String> betType;
	
	public SetBetListener(Player player, JFrame frame, SummaryPanel summaryPanel, TextField betField, JDialog dialog, GameEngine gameEngine, JComboBox<String> betType)
	{
		this.player = player;
		this.frame = frame;
		this.summaryPanel = summaryPanel;
		this.betField = betField;
		this.dialog = dialog;
		this.gameEngine = gameEngine;
		this.betType = betType;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		int bet = -1;
		try
		{
			bet = Integer.parseInt(betField.getText());
		}
		catch(Exception ex)
		{
			new ErrorDialog("Invalid bet!", frame);
		}
		
		if(bet > 0 && bet <= player.getPoints())
		{
			player.setBet(bet);
			
			BetType betType = BetType.BLACK;
			
			switch(this.betType.getSelectedIndex())
			{
				case 0:
					betType = BetType.BLACK;
					break;
				case 1:
					betType = BetType.RED;
					break;
				case 2:
					betType = BetType.ZEROS;
					break;
			}
			
			player.setBetType(betType);
			summaryPanel.updateGUI(gameEngine, frame);
			dialog.dispose();
		}
		else if(bet > player.getPoints())
		{
			new ErrorDialog("Bet must be less than your points!", frame);
		}
		else if(bet == 0)
		{
			new ErrorDialog("Bet must be greater than 0!", frame);
		}
		
	}

}
