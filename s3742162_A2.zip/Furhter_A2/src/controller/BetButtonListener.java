package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;

import model.interfaces.GameEngine;
import model.interfaces.Player;
import view.BetFormGUI;
import view.ErrorDialog;
import view.SummaryPanel;

public class BetButtonListener implements ActionListener{
	
	Player player;
	JFrame frame;
	SummaryPanel summaryPanel;
	GameEngine gameEngine;
	
	public BetButtonListener(Player player, JFrame frame, SummaryPanel summaryPanel, GameEngine gameEngine)
	{
		this.player = player;
		this.frame = frame;
		this.summaryPanel = summaryPanel;
		this.gameEngine = gameEngine;
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		
		if(player.getBet() == 0)
		{
			new BetFormGUI(player, frame, summaryPanel, gameEngine);
		}
		else
		{
			new ErrorDialog("Player bet has been set already!", frame);
		}
		
	}

}
