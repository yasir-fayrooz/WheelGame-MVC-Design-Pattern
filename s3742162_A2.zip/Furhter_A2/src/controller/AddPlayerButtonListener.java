package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;

import model.interfaces.GameEngine;
import view.AddPlayerGUI;
import view.ErrorDialog;
import view.SummaryPanel;

public class AddPlayerButtonListener implements ActionListener{

	GameEngine gameEngine;
	JFrame frame;
	SummaryPanel summaryPanel;
	
	public AddPlayerButtonListener(GameEngine gameEngine, JFrame frame, SummaryPanel summaryPanel)
	{
		this.gameEngine = gameEngine;
		this.frame = frame;
		this.summaryPanel = summaryPanel;
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		
		if(gameEngine.getAllPlayers().size() >= 4)
		{
			new ErrorDialog("Reached maximum players!", frame);
		}
		else
		{
			new AddPlayerGUI(gameEngine, frame, summaryPanel);
		}
	}

}
